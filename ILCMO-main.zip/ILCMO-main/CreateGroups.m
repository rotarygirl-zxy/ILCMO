function [outIndexArray,numberOfGroupsArray] = CreateGroups(numberOfGroups, xPrime,numberOfVariables, method)

outIndexArray = [];
numberOfGroupsArray = [];

[noOfSolutions,D] = size(xPrime);
for sol = 1:noOfSolutions
    switch method
        case 1 %linear grouping
            varsPerGroup = floor(numberOfVariables/numberOfGroups);
            outIndexList = [];
            for i = 1:numberOfGroups-1
               outIndexList = [outIndexList, ones(1,varsPerGroup).*i];
            end
            outIndexList = [outIndexList, ones(1,numberOfVariables-size(outIndexList,2)).*numberOfGroups];
        case 2 %orderByValueGrouping
            varsPerGroup = floor(numberOfVariables/numberOfGroups);
            vars = xPrime(sol,:);
            [~,I] = sort(vars);
            outIndexList = ones(1,numberOfVariables);
            for i = 1:numberOfGroups-1
               outIndexList(I(((i-1)*varsPerGroup)+1:i*varsPerGroup)) = i;
            end
            outIndexList(I(((numberOfGroups-1)*varsPerGroup)+1:end)) = numberOfGroups;
        case 3 %random Grouping
            varsPerGroup = floor(numberOfVariables/numberOfGroups);
            outIndexList = [];
            for i = 1:numberOfGroups-1
               outIndexList = [outIndexList, ones(1,varsPerGroup).*i];
            end
            outIndexList = [outIndexList, ones(1,numberOfVariables-size(outIndexList,2)).*numberOfGroups];
            outIndexList = outIndexList(randperm(length(outIndexList)));
    end
    outIndexArray = [outIndexArray;outIndexList];
    numberOfGroupsArray = [numberOfGroupsArray;numberOfGroups];
    
end
end